<?php
	return [
	'name'=>'الاسم',
	'fullname'=>'الاسم الكامل',
	'address'=>'العنوان',
	'city'=>'المدينة',
	'country'=>'مملكة',
	'pin-code'=>'رمز بين',
	'mobile'=>'رقم الهاتف',
	'account-name'=>'اسم صاحب الحساب',
	'bank_name'=>'اسم البنك',

	
	'payment-method'=>'طريقة الدفع او السداد',
	'cash-on-dlv'=>'الدفع عند الاستلام - السعر مع رسوم التوصيل (في الرياض فقط)',
	'cash-store'=>'نقدا عند استلام الطلب من المتجر',
	'from-wallet'=>'خذ من المحفظة (إذا كان المبلغ كافيا)',
	
	'email'=>'البريد الإلكتروني',
	'subject'=>'موضوع',
	'phone'=>'رقم الجوال',
	'message'=>'رسالتك',
	'send-message'=>'إرسال رسالتك',
	
	'edit-account'=>'تحرير الحساب',
	'create-account'=>'إصنع حساب',
	
	'edit'=>'تصحيح',
	'remove'=>'إزالة',
	'cancel'=>'إلغاء',
	
	'delete'=>'حذف',
	'update'=>'تحديث',
	
	'store-name'=>'اسم المتجر',
	'activity'=>'نشاط',
	'neighbour'=>'حي',
	's-no'=>'مسلسل',
	'street'=>'شارع',
	
	'create-store'=>'تخزين التفاصيل',
	
	'step1'=>'الخطوة 1',
	'step2'=>'الخطوة 2',
	
	'select-store'=>'Select Store'
];
<?php
return[

	'arabic'=>'العربية',
    'home' => 'الصفحة الرئيسية',
    'about' => 'من نحن',
	'why' => 'لماذا أخترتنا',
    'services' => 'خدماتنا',
	'prices' => 'العروض والأسعار',
    'contact' => 'اتصل بنا',
	'customers'=>'عملائنا',
	'client'=>' منطقه العميل ',
	'new-order'=>'طلب جديد',
	'my-orders'=>'طلباتي',
	'orders'=>'الطلبات',
	'info'=>'معلومات شخصية',
    'package-request'=>'طلب الحزمة',
	'support'=>'الدعم',
	'new-ticket'=>'تذكرة جديدة',
	'my-tickets'=>'تذاكري',
];

?>
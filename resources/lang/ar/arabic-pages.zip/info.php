<?php
return [

   'account-details'=>'تفاصيل الحساب',
   'wallet-amount'=>'قيمة المحفظة',
   'package-inside'=>'حزمة داخل',
   'package-outside'=>'حزمة خارج',
   
   'orders-left'=>'طلبات متبقية',
   'days-remaining'=>'الأيام المتبقية',
   
   'my-stores'=>'بلدي مخازن',
   'new-store'=>'أدخل متجر جديد',
   'my-transactions'=>'معاملاتي',
   



];
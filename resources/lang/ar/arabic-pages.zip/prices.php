<?php
return [

    'page-title'=>'العروض والأسعار',
];
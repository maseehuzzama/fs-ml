<?php

return [

	'tagline'=>'فاست ستار للتسليم',

	'book-now'=>'احجز طلبك الآن',
	'read-more'=>'المزيد',
	'submit'=>'عرض',
	'select-one'=>'اختر واحدة',
	'next'=>'التالى',
	'back'=>'الى الخلف',
	'update'=>'تحديث',

	'login'=>'دخول',
	'register'=>'التسجيل',
	'login-title'=>'تسجيل الدخول فاست ستار حتى',
	'new-user'=>'مستخدم جديد؟',
	'forgot-pass'=>'نسيت كلمة السر؟',

	'book-order'=>'احجز أمرك',
	'track-order'=>'تتبع طلبك',

	'footer1-title'=>'عنوان',
	'footer2-title'=>'روابط هامة',
	'footer3-title'=>'البقاء على اتصال',
	
	
	
	'select-order-type'=>'حدد نوع الطلب',
	'new-delivery-order'=>'طلب جديد للتسليم',
	'new-other-order'=>'طلب جديد لخدمات أوث',
	
	
	'edit-order'=>'تعديل الطلب',

	
	
	'transaction-name'=>'اسم المعاملة',
	'trans-no'=>'رقم التحويلة',

	'reference'=>'مرجع',
	'amount'=>'كمية',
	'type'=>'اكتب',
	'balance'=>'توازن',
	'attachment'=>'المرفق',
	
	'order'=>'طلب',
	'orders'=>'طلبات',
	'sar'=>'الريال',

	'phone'=>'رقم الجوال',
	'iban'=>'أي بان',
	
	's-no'=>'مسلسل',
	'store-name'=>'اسم المتجر',
	'street'=>'شارع',
	'neighbour'=>'حي',
	'city'=>'مدينة',
	'country'=>'مملكة',
	
	'store-details'=>'تخزين التفاصيل',
	'new-store'=>'متجر جديد',
	
	'edit-account'=>'تحرير الحساب',
	'create-account'=>'إصنع حساب',
	'edit-store'=>'تحرير المتجر',

	
	'shipment-place'=>'مكان أخذ الشحن',
	'shipment-details'=>'تفاصيل الشحن',
	'shipment-contains'=>'يحتوي على',
	'number-it'=>'عدد العناصر',
	'weight'=>'وزن',
	'pick-date'=>'اختر التاريخ',
	'pick-time'=>'اختر الوقت',
	'spl-req'=>'متطلبات خاصة',
	
	'other-services'=>'خدمات أخرى',
	'packing'=>'التعبئة',
	'packing-yes'=>'نعم , التعبئة السعر:',
	'no'=>'لا',
	
	'packing-color'=>'التعبئة اللون',

	
	'price-details'=>'تفاصيل الأسعار',
	'dlv-chrgs'=>'رسوم التوصيل',
	'insurance-price'=>'سعر التأمين',
	'packing-charges'=>'رسوم التعبئة',
	'freight'=>'إجمالي الأسعار',
	
	'payment-mode'=>'طريقة الدفع',


	'submit-order'=>'أكد الطلب',
	
	'pending-orders'=>'الطلبات معلقة',
	'completed-orders'=>'منجز الطلبات',
	'photo-orders'=>'التصوير الطلبات',
	
	'order-number'=>'رقم الطلب',
	'details'=>'تفاصيل',
	'services'=>'خدمات',
	'date'=>'تاريخ',
	'r_name'=>'اسم المستلم',
	'status'=>'الحالة',
	
	
	'photography'=>'الطلبات للتصوير',
	'photo-quantity'=>'صور الكمية',
	'photo-desc'=>'وصف الصورة',
	'photo-details'=>'وصف الصورة',
	'photo-address'=>'عنوان الطلب',
	'photo-place'=>'مكان الطلب',
	'same-store'=>'نفس عنوان المتجر',
	'photo-prices'=>'أسعار التصوير',

	
	/*Ticket*/
	'support'=>'الدعم',
	'new-ticket'=>'تذكرة جديدة',
	'title'=>'عنوان',
	'category'=>'الفئة',
	'priority'=>'أفضلية',
	'service'=>'نوع الخدمة',
	'message'=>'رسالة',
	'my-tickets'=>'تذاكري',
	'ticket-id'=>'معرف التذكرة',
	'updated_at'=>'آخر تحديث',
	'reply'=>'الرد',
	'by'=>'بواسطة',
	
	
	/*Agent*/
	'agent'=>'وكيل',
	'dlv-agent'=>'وكيل للتسليم',
	'pick-agent'=>'وكيل لاختيار',

	'new-orders'=>'طلبات جديدة',
	'coming-orders'=>'القادمة طلبات',
	
	'to-pick'=>'لاختيار',
	'to-dlvr'=>'للتسليم',
	'dlv-place'=>'مكان التسليم',
	'cash-list'=>'قائمة النقدية',
	
	'actions'=>'أفعال',
	'store-city'=>'مخزن المدينة',
	'receiver-city'=>'مدينة التسليم',
	'cod'=>'الدفع عن الاستلام',
	'cfs'=>'النقدية من المتجر',
	'update-status'=>'تحديث الحالة',
	'change-status'=>'تحديث الحالة',
	'all-orders'=>'جميع الطلبات',
	'today-orders'=>'اليوم الطلبات',
	'dated'=>'بتاريخ',
	'origin'=>'من عند',
	'destination'=>'المكان التسليم',

	'signatures'=>'التوقيعات',

	'report'=>'تقارير',
	'dlv-report'=>'تقارير التسليم',
	'pick-report'=>'تقارير قطف',

	'new-package-requests'=>'طلبات حزمة جديدة',
	'support-tickets'=>'تذاكر الدعم',
	
	'name'=>'اسم',
	'region'=>'منطقة',
	'insurance'=>'تأمين',
	'return'=>'إرجاع',
	
	'account'=>'الحساب',
	'username'=>'اسم المستخدم',
	'take-amount'=>'خذ المبلغ',
	
	'password'=>'كلمه السر',
	'optional'=>'اختياري',
	
	'region'=>'منطقة',
	'new'=>'الجديد',
	'list'=>'قائمة',
	'id'=>'هوية شخصية',
	

	'admin'=>'مشرف',
	'admins-employees'=>'المشرف والموظفين',
	'supervisor'=>'مشرف',
	'assign-city'=>'تعيين المدينة',
	'account-cities'=>'الحساب والمدن',
	'work-cities'=>'مدن العمل',
	'wallet_amount'=>'قيمة المحفظة',
	'closed'=>'مغلق',
	'tickets'=>'تذاكر',
	'ticket'=>'تذكرة',
	'user'=>'المستعمل',
	'stage'=>'المسرح',
	'pending'=>'قيد الانتظار',
	'number'=>'رقم',
	'client'=>'زبون',
	'total-prices'=>'إجمالي الأسعار',
	'quantity'=>'كمية',
	'storage-prices'=>'سعر التخزين',


];
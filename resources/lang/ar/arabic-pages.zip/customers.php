<?php
return [

    'page-title'=>'عملائنا',
    'description'=>'تجد عملائنا العادية',

];
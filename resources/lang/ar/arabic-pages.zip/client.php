<?php

return [

    /*Order*/
    'new-order'=> 'طلب جديد',
    'orders'=> 'طلباتك',
    'my-orders-title'=>'طلباتك',
	

	/*New-Order*/
	
	'new-order-form-title'=>'تفاصيل ألطلب الجديدة',
	'shipment-details'=>'تفاصيل الشحنة',
	'shipment-contains'=>'شحنة يحتوي',
	'number-it'=>'عدد منه',
	'other'=>'خدمات أخرى',
	'packaging'=>'التعبئة والتغليف',
	'insurance'=>'تأمين',
	'est-weight'=>'الوزن المقدر',
	'rcvr-info'=>'معلومات الاستقبال',

    /*Info*/
	
    'info'=>'معلومات العميل الشخصية',


    /*package*/
    'package-request'=>'طلب حزمة',
    'package-details'=>'طلب حزمة',
    'package-type'=>'نوع الحزمة',
    'package'=>'صفقة',
    'inside-riyadh'=>'داخل الرياض',
    'outside-riyadh'=>'خارج الرياض',
	
	
	'payment-method'=>'طريقة الدفع او السداد',
'cash-on-dlv'=>'الدفع عند الاستلام - السعر مع رسوم التوصيل (في الرياض فقط)',
'cash-store'=>'نقدا عند استلام الطلب من المتجر',
'from-wallet'=>'خذ من المحفظة (إذا كان المبلغ كافيا)',
	
	
];